Install Instructions:
- Download apk on android device
- Open apk (make sure install from anywhere enabled)
- Open and allow to use camera
- Play!

Note:
UI has been scaled to work with a 1440x2560 resolution phone screen, UI might be off for other phones